﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovPj2 : MonoBehaviour {
    public float movementSpeed = 5f;
    public GameObject bulletPrefab;
    public Transform bulletSpawn;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        transform.Translate(new Vector3(0f, 0f, Input.GetAxis("Vertical1")) * Time.deltaTime * movementSpeed);
        transform.Rotate(new Vector3(0f, Input.GetAxis("Horizontal1"), 0f));
        if (Input.GetKeyDown(KeyCode.R))
        {
            Fire();
        }
        
    }
    void Fire()
    {
        // Create the Bullet from the Bullet Prefab
        var bullet = (GameObject)Instantiate(
            bulletPrefab,
            bulletSpawn.position,
            bulletSpawn.rotation);

        // Add velocity to the bullet
        bullet.GetComponent<Rigidbody>().velocity = bullet.transform.forward * 6;

        // Destroy the bullet after 2 seconds
        Destroy(bullet, 2.0f);
    }
}
