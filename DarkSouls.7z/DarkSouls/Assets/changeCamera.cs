﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class changeCamera : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.C))
        {
            swapCamera();
        }
        if (Input.GetKeyDown(KeyCode.V))
        {
            ShowFirstPersonView();
        }
    }
    public Camera firstPersonCamera;
    public Camera overheadCamera;

    void swapCamera()
    {
        firstPersonCamera.enabled = false;
        overheadCamera.enabled = true;
    }

    void ShowFirstPersonView()
    {
        firstPersonCamera.enabled = true;
        overheadCamera.enabled = false;
    }
}
